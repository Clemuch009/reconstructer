# profiles/resolver.py
#
# Generic Profile Resolver.
#
# Turns raw pipeline output (key-value pairs + tables, from the filter layer)
# into a canonical **Document View** {fields, tables, metadata} by following a
# profile's declarative resolution strategies. It is GENERIC — it contains no
# invoice/contract/etc. knowledge; all domain meaning comes from the profile
# data it reads. The same resolver serves every profile.
#
# Resolution model (per canonical field):
#   The profile lists an ordered set of strategies. The resolver tries them in
#   order and stops at the FIRST successful match (order = priority):
#     {"from": "key_values", "aliases": [...]}  → match a kv key by alias
#     {"from": "tables",     "columns": [...]}  → take first cell of a column
#   New strategy kinds can be added here without changing the profile format.
#
# Output: the canonical Document View consumed by analysis/rules_engine.py.

from typing import Any, Dict, List, Optional


# ── normalization ────────────────────────────────────────────────────────

def _norm(label: Any) -> str:
    """Normalize a label for matching: lowercase, trimmed, trailing colon and
    surrounding whitespace removed, and a trailing parenthetical unit/qualifier
    stripped so "Total Due (USD)" matches "Total Due" and "Tax (0%)" matches
    "Tax". Purely syntactic (no domain knowledge)."""
    import re as _re
    s = str(label).strip()
    if s.endswith(":"):
        s = s[:-1].strip()
    # strip a single trailing parenthetical: "Total Due (USD)" -> "Total Due"
    s = _re.sub(r"\s*\([^)]{1,12}\)\s*$", "", s).strip()
    return s.lower()


def _headers_of(table: Dict[str, Any]) -> List[Any]:
    """Table headers as a list. Some extractors emit `headers: None` (e.g. a
    spreadsheet block with no recognizable header row); treat that as absent
    rather than crashing."""
    h = table.get("headers")
    return h if isinstance(h, list) else []


def _rows_of(table: Dict[str, Any]) -> List[Any]:
    """Table rows as a list; tolerates a missing or null `rows` key."""
    r = table.get("rows")
    return r if isinstance(r, list) else []


# ── strategy: key_values ──────────────────────────────────────────────────

def _resolve_from_key_values(
    strategy: Dict[str, Any],
    kv_index: Dict[str, List[Any]],
) -> Optional[List[Any]]:
    """Return ALL kv values whose key matches one of the aliases (first alias
    that matches anything wins, but every value under it is returned). Never
    discards competing values — the caller applies cardinality rules."""
    for alias in strategy.get("aliases", []):
        vals = kv_index.get(_norm(alias))
        if vals:
            return list(vals)
    return None


# ── strategy: tables (scalar from a column's first cell) ──────────────────

def _resolve_from_tables(
    strategy: Dict[str, Any],
    tables: List[Dict[str, Any]],
) -> Optional[Any]:
    """Return the first cell of the first column (by alias) found in any table.
    Used for scalar fields that live in a table (e.g. a 'Total' cell)."""
    wanted = [_norm(c) for c in strategy.get("columns", [])]
    for table in tables:
        headers = [_norm(h) for h in _headers_of(table)]
        for w in wanted:
            if w in headers:
                idx = headers.index(w)
                for row in _rows_of(table):
                    cell = _cell(row, idx)
                    if cell is not None and str(cell).strip() != "":
                        return cell
    return None


def _cell(row: Any, idx: int) -> Optional[Any]:
    """Get cell at column index from a row that may be a list or a dict
    (col_0.. or header-keyed). Returns None if absent."""
    if isinstance(row, list):
        return row[idx] if idx < len(row) else None
    if isinstance(row, dict):
        # try positional col_N, then the idx-th value
        key = f"col_{idx}"
        if key in row:
            return row[key]
        vals = list(row.values())
        return vals[idx] if idx < len(vals) else None
    return None


_STRATEGIES = {
    "key_values": _resolve_from_key_values,
    "tables":     _resolve_from_tables,
}


# ── table mapping (line-items) ────────────────────────────────────────────

def _build_kv_index(kv_pairs: List[Dict[str, Any]]) -> Dict[str, List[Any]]:
    """
    Index kv pairs by normalized key, collecting ALL values in document order.

    Deliberately NOT "first occurrence wins". A resolver is never allowed to
    discard competing values: if a document anchor (invoice_number, vendor)
    appears twice, that is evidence the input is not one logical document. The
    caller decides what that means; the index must not destroy the evidence.
    """
    index: Dict[str, List[Any]] = {}
    for p in kv_pairs:
        k = _norm(p.get("key"))
        if k:
            index.setdefault(k, []).append(p.get("value"))
    return index


def _distinct(values: List[Any]) -> List[Any]:
    """Distinct values, order-preserving. Values equal after trimming are the
    same value (a repeated header restating the same invoice number is not a
    competing root)."""
    seen, out = set(), []
    for v in values:
        key = str(v).strip()
        if key not in seen:
            seen.add(key)
            out.append(v)
    return out


def _map_line_items(
    spec: Dict[str, Any],
    tables: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Find the source table matching `identify_by` and remap its columns to
    canonical line-item field names. Returns a list of {canonical: value}."""
    identify = [_norm(c) for c in spec.get("identify_by", [])]
    col_map  = spec.get("columns", {})

    # pick the first table whose headers include any identify_by signature
    chosen = None
    for table in tables:
        headers = [_norm(h) for h in _headers_of(table)]
        if any(sig in headers for sig in identify):
            chosen = table
            break
    if chosen is None:
        return []

    headers = [_norm(h) for h in _headers_of(chosen)]
    # resolve each canonical column to a source index
    canon_to_idx: Dict[str, int] = {}
    for canon, aliases in col_map.items():
        for a in aliases:
            na = _norm(a)
            if na in headers:
                canon_to_idx[canon] = headers.index(na)
                break

    items: List[Dict[str, Any]] = []
    for row in _rows_of(chosen):
        item: Dict[str, Any] = {}
        for canon, idx in canon_to_idx.items():
            cell = _cell(row, idx)
            if cell is not None:
                item[canon] = cell
        if item:
            items.append(item)
    return items


# ── public API ────────────────────────────────────────────────────────────

PARTITION_SINGLE    = "SINGLE_DOCUMENT"
PARTITION_MULTI     = "MULTI_DOCUMENT_DETECTED"
PARTITION_AMBIGUOUS = "AMBIGUOUS"


def resolve_document_view(
    kv_pairs: List[Dict[str, Any]],
    tables:   List[Dict[str, Any]],
    profile:  Dict[str, Any],
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Build a canonical Document View from raw pipeline output using a profile's
    declarative resolution strategies.

    ── Hard architectural invariant ─────────────────────────────────────────
    A resolver is NEVER allowed to discard competing root entities. If a field
    the profile declares `cardinality: exactly_one` resolves to two distinct
    values, the input is not one logical document. That is a PARTITION error,
    not a validation error — and the resolver refuses to pick a winner.

    Rather than confidently returning a plausible but blended document, the
    view carries `partition` status:

        SINGLE_DOCUMENT         — one document root; fields resolved normally
        MULTI_DOCUMENT_DETECTED — competing anchors; suspicion >= threshold
        AMBIGUOUS               — some repetition, below threshold

    When status is not SINGLE_DOCUMENT, anchor fields with competing values are
    left UNRESOLVED (absent from `fields`) and reported in
    `partition.boundary_candidates`. Refusing to produce a believable lie is
    more valuable than producing a complete-looking answer.

    Returns
    -------
    {
      "fields":   {canonical_field: value},
      "tables":   {name: [ {canonical_col: value} ]},
      "metadata": {...},
      "_resolution": {field: strategy_used | None},
      "partition": {
          "status": ..., "confidence": float,
          "boundary_candidates": [ {field, values, anchor_weight} ],
      },
    }
    """
    kv_index = _build_kv_index(kv_pairs)
    schema   = profile.get("schema", {})
    threshold = profile.get("partition", {}).get("suspicion_threshold", 0.8)

    fields: Dict[str, Any] = {}
    trace:  Dict[str, Any] = {}
    candidates: List[Dict[str, Any]] = []
    suspicion = 0.0

    for field, strategies in profile.get("field_resolution", {}).items():
        values = None
        used   = None
        for strategy in strategies:
            kind = strategy.get("from")
            fn = _STRATEGIES.get(kind)
            if fn is None:
                continue
            if kind == "key_values":
                values = fn(strategy, kv_index)
            elif kind == "tables":
                single = fn(strategy, tables)
                values = [single] if single is not None else None
            if values:
                used = kind
                break

        trace[field] = used
        if not values:
            continue

        spec        = schema.get(field, {})
        cardinality = spec.get("cardinality", "one")
        weight      = float(spec.get("anchor_weight", 0.0))
        distinct    = _distinct(values)

        if cardinality == "many":
            fields[field] = distinct
            continue

        if len(distinct) > 1:
            # Competing root entities. Do NOT choose. Record evidence.
            candidates.append({
                "field":         field,
                "values":        distinct,
                "cardinality":   cardinality,
                "anchor_weight": weight,
            })
            suspicion += weight
            if cardinality == "exactly_one":
                # An anchor conflict: leave the field unresolved entirely.
                continue
            # Weaker cardinality: still refuse to blend; leave unresolved.
            continue

        fields[field] = distinct[0]

    suspicion = min(1.0, round(suspicion, 4))
    if not candidates:
        status = PARTITION_SINGLE
        confidence = 1.0
    elif suspicion >= threshold:
        status = PARTITION_MULTI
        confidence = suspicion
    else:
        status = PARTITION_AMBIGUOUS
        confidence = suspicion

    # line-item and other declared tables
    out_tables: Dict[str, Any] = {}
    for name, spec in profile.get("tables", {}).items():
        mapped = _map_line_items(spec, tables)
        if mapped:
            out_tables[name] = mapped

    return {
        "fields":      fields,
        "tables":      out_tables,
        "metadata":    metadata or {},
        "_resolution": trace,
        "partition": {
            "status":              status,
            "confidence":          confidence,
            "boundary_candidates": candidates,
            "action": ("requires_partition"
                       if status != PARTITION_SINGLE else None),
        },
    }
