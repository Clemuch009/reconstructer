# relationship_engine/structural.py
#
# Structural matching — aligns the LINE ITEMS of two documents.
#
# Its sole job is to answer "how do these two structures correspond?" — NOT
# "do the values match" and NOT "is this approved". It produces a mapping
# (matched pairs, unmatched-left, unmatched-right) that the financial and
# business dimensions then consume. No verdict here.
#
# Why this is fundamental, not a feature: the moment either side has line items
# (invoices and POs always do), header-only matching is incomplete by
# construction. PO says 10 laptops, invoice says 8 — the header total can look
# fine while 2 units were never delivered. Only line alignment surfaces that.
#
# ── Correctness properties ────────────────────────────────────────────────
#   • Alignment is by EVIDENCE, not position — reordered rows align correctly.
#   • 1:1 alignment is implemented and correct.
#   • Split lines (1 PO line → 2 invoice lines) and merged lines are NOT
#     silently guessed. They are reported as unmatched, so the engine says
#     "these lines didn't align, review them" rather than fabricating a match.
#     That is fail-closed: safe, not wrong. (Split/merge resolution is a later
#     capability; its absence never produces an incorrect mapping.)

import re
from typing import Any, Dict, List, Optional, Tuple


# ── line normalization ─────────────────────────────────────────────────────
#
# Two documents describe the same line with different schemas (qty vs quantity,
# unit_price vs rate). A structural profile maps each side's columns into a
# common vocabulary so lines are comparable. This mirrors the resolver's field
# mapping, at the line level.

def _norm_text(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v).strip().lower()) if v is not None else ""

_NUM_RE = re.compile(r"-?[\d,]*\.?\d+")

def _num(v: Any) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    m = _NUM_RE.search(str(v).replace(",", ""))
    return float(m.group()) if m else None


def _canonical_line(line: Dict[str, Any], col_map: Dict[str, List[str]]) -> Dict[str, Any]:
    """Map one raw line dict into the common vocabulary declared by col_map:
      {"description": ["description","item"], "quantity": ["qty","quantity"], ...}
    First matching source column wins. Returns {canonical_field: value}."""
    lower = { _norm_text(k): v for k, v in line.items() }
    out: Dict[str, Any] = {}
    for canon, aliases in col_map.items():
        for a in aliases:
            na = _norm_text(a)
            if na in lower and lower[na] is not None:
                out[canon] = lower[na]
                break
    return out


# ── evidence-based line similarity ─────────────────────────────────────────
#
# Each candidate pairing accrues weighted evidence across declared fields. A
# line pairs with its best-supported counterpart, not the one in the same
# position. Weights come from the structural profile (data), not hardcoded.

def _field_agrees(canon_field: str, a_val: Any, b_val: Any) -> bool:
    """Deterministic agreement test. Numeric fields compare as numbers (with a
    tiny tolerance); everything else compares as normalized text equality."""
    an, bn = _num(a_val), _num(b_val)
    if an is not None and bn is not None:
        return abs(an - bn) <= 0.001
    return _norm_text(a_val) == _norm_text(b_val)


def _pair_evidence(
    a_line: Dict[str, Any],
    b_line: Dict[str, Any],
    weights: Dict[str, float],
) -> Tuple[float, List[Dict[str, Any]]]:
    """Weighted evidence that a_line and b_line are the same line. Returns
    (score 0..1, evidence[]). Only fields present on BOTH sides contribute;
    a field absent on one side is neither agreement nor disagreement."""
    total_w = 0.0
    got_w   = 0.0
    evidence: List[Dict[str, Any]] = []
    for field, w in weights.items():
        if field in a_line and field in b_line:
            total_w += w
            agrees = _field_agrees(field, a_line[field], b_line[field])
            if agrees:
                got_w += w
            evidence.append({
                "field": field, "weight": w, "agrees": agrees,
                "a": a_line[field], "b": b_line[field],
            })
    score = round(got_w / total_w, 4) if total_w > 0 else 0.0
    return score, evidence


# ── identity-based candidate generation ────────────────────────────────────
#
# Don't compare every line to every line. A line's identity field(s) (sku,
# product_code, description) generate candidates; only lines sharing identity
# evidence are scored. Falls back to scoring all pairs when no identity field
# is available (small line counts make this acceptable).

def _identity_signature(line: Dict[str, Any], identity_fields: List[str]) -> Optional[str]:
    parts = [_norm_text(line[f]) for f in identity_fields if f in line and line[f] is not None]
    return "|".join(parts) if parts else None


ALIGN_THRESHOLD = 0.75   # minimum evidence score to accept a 1:1 alignment


def align_lines(
    a_lines: List[Dict[str, Any]],
    b_lines: List[Dict[str, Any]],
    profile: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Align two lists of line items by evidence.

    profile (declarative) supplies:
      "columns":   {canonical: [aliases...]}         — per side vocabulary map
      "identity":  [canonical fields for candidacy]  — e.g. ["description","sku"]
      "weights":   {canonical: weight}               — evidence weighting
      "allow":     ["reorder"] (splits/merges deferred → reported unmatched)

    Returns:
      {
        "matched":   [ {a_index, b_index, score, evidence} ],
        "unmatched_left":  [a_index, ...],
        "unmatched_right": [b_index, ...],
        "summary": {a_total, b_total, matched, unmatched_left, unmatched_right},
      }

    1:1 only. A line that has no counterpart above threshold — including split
    or merged lines — is reported unmatched, never force-fit.
    """
    col_map = profile.get("columns", {})
    identity_fields = profile.get("identity", [])
    weights = profile.get("weights", {})

    A = [_canonical_line(l, col_map) for l in a_lines]
    B = [_canonical_line(l, col_map) for l in b_lines]

    # candidate pairs via identity signature (prunes the comparison space)
    b_by_sig: Dict[str, List[int]] = {}
    for j, bl in enumerate(B):
        sig = _identity_signature(bl, identity_fields)
        if sig is not None:
            b_by_sig.setdefault(sig, []).append(j)

    # score candidate pairs
    scored: List[Tuple[float, int, int, List[Dict[str, Any]]]] = []
    for i, al in enumerate(A):
        sig = _identity_signature(al, identity_fields)
        candidates = b_by_sig.get(sig, []) if sig is not None else list(range(len(B)))
        if sig is None and not identity_fields:
            candidates = list(range(len(B)))
        for j in candidates:
            score, ev = _pair_evidence(al, B[j], weights)
            if score >= ALIGN_THRESHOLD:
                scored.append((score, i, j, ev))

    # greedy best-first 1:1 assignment (deterministic: highest score wins,
    # ties broken by index order). A line already used cannot be reused —
    # which is exactly why a split (1→2) leaves the second line unmatched.
    scored.sort(key=lambda t: (-t[0], t[1], t[2]))
    used_a, used_b = set(), set()
    matched: List[Dict[str, Any]] = []
    for score, i, j, ev in scored:
        if i in used_a or j in used_b:
            continue
        used_a.add(i); used_b.add(j)
        matched.append({"a_index": i, "b_index": j, "score": score, "evidence": ev})

    unmatched_left  = [i for i in range(len(A)) if i not in used_a]
    unmatched_right = [j for j in range(len(B)) if j not in used_b]

    return {
        "matched": matched,
        "unmatched_left":  unmatched_left,
        "unmatched_right": unmatched_right,
        "summary": {
            "a_total": len(A), "b_total": len(B),
            "matched": len(matched),
            "unmatched_left":  len(unmatched_left),
            "unmatched_right": len(unmatched_right),
        },
    }
