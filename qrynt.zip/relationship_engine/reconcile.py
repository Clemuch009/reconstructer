# relationship_engine/reconcile.py
#
# Document-to-document reconciliation: takes two Document Views and produces a
# multi-dimensional Verdict. This is the single edge of the reconciliation
# graph — two documents, reconciled across independent dimensions.
#
# Dimensions computed here:
#   Identity   — fact-based weighted edge over declared identity fields
#   Financial  — declared financial rules via the Rules Engine (order-agnostic)
#   Structural — line alignment mapping (relationship_engine.structural)
#   Business   — quantity/fulfillment discrepancies read off the alignment
#   Compliance — NOT_CHECKED (needs company policy data — fail-closed)
#
# All WHAT/HOW is declarative profile data; this module is generic.

from typing import Any, Dict, List

from relationship_engine.verdict import (
    Verdict, IDENTITY, FINANCIAL, STRUCTURAL, BUSINESS, COMPLIANCE,
    PASS, FAIL, NOT_CHECKED,
)
from relationship_engine.structural import align_lines, _num


# ── Identity: the fact-based weighted edge ─────────────────────────────────
#
# The edge is NOT one key. It is a weighted bundle of facts (invoice_number
# 0.6 + amount 0.2 + currency 0.1 + vendor 0.1). A missing field weakens the
# edge; other facts still carry it. Edge holds if evidence >= threshold.

def _edge_identity(a_fields, b_fields, spec):
    weights = spec.get("weights", {})          # {a_field: {"b": b_field, "w": w}}
    threshold = spec.get("threshold", 0.7)
    total_w = got_w = 0.0
    evidence = []
    for a_field, m in weights.items():
        b_field = m["b"]; w = float(m["w"])
        if a_field in a_fields and b_field in b_fields:
            total_w += w
            an, bn = _num(a_fields[a_field]), _num(b_fields[b_field])
            if an is not None and bn is not None:
                agrees = abs(an - bn) <= float(m.get("tolerance", 0.001))
            else:
                agrees = str(a_fields[a_field]).strip().lower() == str(b_fields[b_field]).strip().lower()
            if agrees:
                got_w += w
            evidence.append({"a_field": a_field, "b_field": b_field, "weight": w,
                             "agrees": agrees, "a": a_fields[a_field], "b": b_fields[b_field]})
        else:
            evidence.append({"a_field": a_field, "b_field": b_field, "weight": w,
                             "agrees": None, "note": "field absent on a side"})
    score = round(got_w / total_w, 4) if total_w > 0 else 0.0
    return (PASS if score >= threshold else FAIL), score, evidence


# ── Financial: declared rules via the Rules Engine ─────────────────────────

def _financial(a_fields, b_fields, rules):
    if not rules:
        return NOT_CHECKED, []
    from analysis.rules_engine import evaluate
    combined = {"fields": {}}
    for k, v in a_fields.items(): combined["fields"][f"a.{k}"] = v
    for k, v in b_fields.items(): combined["fields"][f"b.{k}"] = v
    report = evaluate(combined, rules)
    evidence = [{"rule": r["rule_id"], "status": r["status"], **r.get("evidence", {})}
                for r in report["results"]]
    status = FAIL if report["summary"]["failed"] > 0 else PASS
    return status, evidence


# ── Structural + Business from the line alignment ──────────────────────────

def _structural_and_business(a_tables, b_tables, struct_profile):
    line_key = struct_profile.get("line_table", "line_items")
    a_lines = a_tables.get(line_key, [])
    b_lines = b_tables.get(line_key, [])
    if not a_lines and not b_lines:
        return (NOT_CHECKED, [], {}), (NOT_CHECKED, [], {})

    alignment = align_lines(a_lines, b_lines, struct_profile)
    s = alignment["summary"]

    # Structural: did the lines correspond? Unmatched lines on either side fail
    # the structural dimension (something didn't align — review it).
    struct_status = PASS if (s["unmatched_left"] == 0 and s["unmatched_right"] == 0) else FAIL
    struct_detail = alignment

    # Business: for aligned pairs, did quantities/fulfillment agree? A matched
    # pair whose quantity differs is a fulfillment discrepancy (partial
    # delivery), even if identity/financial pass.
    qty_field = struct_profile.get("quantity_field", "quantity")
    biz_evidence = []
    biz_fail = False
    for m in alignment["matched"]:
        a_line = a_lines[m["a_index"]]
        b_line = b_lines[m["b_index"]]
        qa = _num(_get_ci(a_line, qty_field))
        qb = _num(_get_ci(b_line, qty_field))
        if qa is not None and qb is not None and abs(qa - qb) > 0.001:
            biz_fail = True
            biz_evidence.append({"a_index": m["a_index"], "b_index": m["b_index"],
                                 "quantity_a": qa, "quantity_b": qb,
                                 "difference": round(qb - qa, 4),
                                 "note": "quantity discrepancy (possible partial fulfillment)"})
    # unmatched lines are also a business concern (something ordered/billed absent)
    if s["unmatched_left"] or s["unmatched_right"]:
        biz_evidence.append({"unmatched_left": alignment["unmatched_left"],
                             "unmatched_right": alignment["unmatched_right"],
                             "note": "lines with no counterpart"})
        biz_fail = True
    biz_status = FAIL if biz_fail else PASS

    return (struct_status, [], struct_detail), (biz_status, biz_evidence, {})


def _get_ci(d, field):
    """Case-insensitive dict get."""
    if field in d: return d[field]
    lf = field.lower()
    for k, v in d.items():
        if str(k).lower() == lf:
            return v
    return None


# ── public API ─────────────────────────────────────────────────────────────

def reconcile_documents(
    view_a: Dict[str, Any],
    view_b: Dict[str, Any],
    profile: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Reconcile two Document Views into a multi-dimensional Verdict.

    profile (declarative):
      "identity":   {"weights": {a_field: {"b": b_field, "w": .., "tolerance": ..}},
                     "threshold": ..}
      "financial":  [ rules referencing a.<f> / b.<f> ]
      "structural": {"line_table","columns","identity","weights",
                     "quantity_field"}
      (compliance intentionally omitted → NOT_CHECKED)
    """
    a_fields = view_a.get("fields", {})
    b_fields = view_b.get("fields", {})
    a_tables = view_a.get("tables", {})
    b_tables = view_b.get("tables", {})

    v = Verdict()

    # Identity
    id_spec = profile.get("identity")
    if id_spec:
        status, score, ev = _edge_identity(a_fields, b_fields, id_spec)
        v.set(IDENTITY, status, evidence=ev, detail={"edge_score": score})

    # Financial
    fin_status, fin_ev = _financial(a_fields, b_fields, profile.get("financial", []))
    if fin_status != NOT_CHECKED:
        v.set(FINANCIAL, fin_status, evidence=fin_ev)

    # Structural + Business
    struct_profile = profile.get("structural")
    if struct_profile:
        (s_status, s_ev, s_detail), (b_status, b_ev, b_detail) = \
            _structural_and_business(a_tables, b_tables, struct_profile)
        if s_status != NOT_CHECKED:
            v.set(STRUCTURAL, s_status, evidence=s_ev, detail=s_detail)
        if b_status != NOT_CHECKED:
            v.set(BUSINESS, b_status, evidence=b_ev, detail=b_detail)

    # Compliance stays NOT_CHECKED (needs company policy data) — fail-closed.
    return v.to_dict()
